import core.unified_template.jinja_filters  # don't delete - it's used to load  filters before first jinja usage
