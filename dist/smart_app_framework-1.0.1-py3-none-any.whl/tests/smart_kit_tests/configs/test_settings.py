# coding: utf-8
import unittest
from unittest.mock import Mock
from smart_kit.configs import settings


class SettingsTest1(unittest.TestCase):
    def test_Settings(self):
        pass
